
# objects should be of same type
print( 43 + 4)

print("hello" + "python")
#print("hello" + 9)
print("hello" + str(9))

alist = [10,20,30]
print(alist * 4)
name ='python'
print(name * 4)

name = 'python programming'
if 'ram' in name:
    print("substring exists")
else:
    print("substring doesnt exist")
    
book = {"chap1":10 ,"chap2":20}
if 'chap3' in book:
    print("key exists")
    
    
alist = [10,20,30,40]
if 10 in alist:
    print("exists")



    
    