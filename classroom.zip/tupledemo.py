
# list
alist = [20,40,50,60]
alist[0] = 100
print(alist)



# tuple
atup = (10,30,40,40)
#atup[0] = 100
print(atup)

# typecasting - converting from one object to another object
atup = (10,30,40,40)
alist = list(atup)  # convertin to list
alist[0] = 100      # making changes
atup = tuple(alist) # converting to tuple
print(atup)






