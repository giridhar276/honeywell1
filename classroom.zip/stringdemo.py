

print(10,20,30,40)
name = 'python programming'
print(name)
print("I love",name)

#this is the single line comment

'''
this is
multi line 
comment
'''
name = 'python programming'
# slicing
#string[start:stop:incremental]
print(name[0])
print(name[1])
print(name[0:5])
print(name[1:4])
print(name[8:10])
print(name[8:10:1])
print(name[0:18])
print(name[0:18:1])
print(name[0:18:2])
print(name[1:18:2])
print(name[:])
print(name[::])
print(name[-1])
print(name[-2])
print(name[-4:-1])
print(name[::-1])




name = 'python programming'
print(name.capitalize())
print(name.title())
print(name.center(40))
print(name.center(40,"*"))
print(name.count('p'))
print(name.count('z'))
print(name.endswith('g'))
print(name.startswith('q'))
print(name.find('ram'))  # -1 if not existing 
                         # index position if existing
aname = "I love {} and {}"
print(name.format('python','c'))
print(name.format('unix','java'))
print(name.isupper())
print(name.islower())
print(name.split(" "))     # converting string to list
print(name.replace("python","java"))

bname = "  python "
print(len(bname))
print(len(bname.strip()))
print(len(bname.lstrip()))
print(len(bname.rstrip()))

data = ["unix","programming"] # converting list to the string
print(":".join(data))

















