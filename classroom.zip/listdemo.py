alist = [10,45,24,56,32,45,13,45,56,91,27]
# list.append(value) - add single object to the end of the list
alist.append(90)

print('After appending :',alist)
# list.extend(list)  - add multiple values
alist.extend([45,34,32,98])
print('After extending :',alist)
#list.insert(index,value)
alist.insert(1,25)
print('After inserting :',alist)
#list.pop(index)
getcount = alist.count(45)
print(getcount)
alist.pop(1)   # 1 is the index
print('After pop operation :',alist)
#list.remove(value)
alist.remove(45) #45 is removed from the list
print(alist) 
alist.sort()
print('After sorting :',alist)
alist.reverse()
print('After reversing :',alist)