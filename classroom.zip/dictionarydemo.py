book = {"chap1":10 ,"chap2": 20 ,"chap3":30 }
# display keys
print(book.keys())
# display values
print(book.values())
# display key-value pairs
print(book.items())
# remove key-value pair using key
book.pop('chap1')
print('After pop :', book)
# add new key-value pairs
book['chap4'] = 40
book['chap5'] = 50
print(book)
# access values  :dict[key]
print(book['chap2'])
print(book['chap4'])
newbook = {"chap6":60,'chap7':70}
# method1
finalbook = {**book,**newbook}
print(finalbook)
# method2
book.update(newbook)