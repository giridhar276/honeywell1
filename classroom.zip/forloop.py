# displaying all the numbers from 1 to 10
# range(start,stop,step)
for val in range(1,11):
    print(val)

for val in range(11,0,-1):
    print(val)
    
name = 'python'
for char in name:
    print(char)
    
alist = [10,20,30,40]
for val in alist:
    print(val)
    
#for loop with dict
book = {"chap1":10 , "chap2":20 }
for key in book.keys():
    print(key)
    
for value in book.values():
    print(value)

for key,value in book.items():
    print(key,value)
    
    
aset = {10,10,10,20,30,30}
for val in aset:
    print(val)



    
    