
'''
write a program to read adult.csv and display workclass and occupation colums only
'''
import csv   
try:
    with open('adult111.csv','r') as fobj:
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print("workclass :",line[1])
            print("occupation:",line[6])
except TypeError as err:
    print("system error :",err)
except ValueError as err:
    print("system error :",err)
except (KeyError,IndexError) as err:
    print(err)
except FileNotFoundError as err:
    print(err)
except Exception as err:  # default excepton # baseclass exception
    print(err)