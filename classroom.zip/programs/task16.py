# -*- coding: utf-8 -*-
"""
write a program to read adult.csv , replace all the lines containing  United-States
with USA and write the to output to adultinfo_US.csv file

"""

try:
    with open('adult.csv','r') as fr, open('backup.csv','w') as fw:
        for line in fr:
            line = line.replace('United-States','USA')
            fw.write(line)
except Exception as err:
    print(err)