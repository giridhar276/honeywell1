

'''
write a program to capture any string from the keyboard and perform the below

if the string is defined in uppercase......   convert the string to lower and display it

if the string is defined in lowercase ...... convert the string to upper and displat it.


'''

string = input("Enter any string :")
if string.isupper():
    print(string.lower())
elif string.islower():
    print(string.upper())