# -*- coding: utf-8 -*-
"""
create two folders as below in the local directory
source       :  ( copy few files to the source folder)
destination  :  --- will be empty --

write a program to copy all the files from source folder to destination folder

"""

import os
import shutil
try:
    source = r'C:\Users\gsripath\Desktop\programs\source'
    destination = r'C:\Users\gsripath\Desktop\programs\destination'
    
    for file in os.listdir(source):
        if not os.path.isfile(destination + "\\" + file):
            shutil.copy(source + "\\" + file,destination)
            print(file,"copied to",destination)
        else:
            print(file,"is already existing in",destination)
except Exception as err:
    print(err)    