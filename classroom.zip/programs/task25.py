

import os

#os.mkdir("example")

try:
    for val in range(1,11):
        dirname = "dir" + str(val)
        if not os.path.isdir(dirname):
            os.mkdir(dirname)
        else:
            print(dirname,"already exists")
except Exception as err:
    print(err)