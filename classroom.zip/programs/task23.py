# -*- coding: utf-8 -*-
"""
write a program to display all the files and its size

Output:
file1.py   100 bytes
file2.py    34 bytes
..
..
"""

import os
try:
    files = os.listdir()
    for file in files:
        if os.path.isfile(file):
            print(file.ljust(20), os.path.getsize(file),"bytes")
except Exception as err:
    print(err)
