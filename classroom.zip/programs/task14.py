'''
write a program to read adult.csv aand display distinct workclasses
'''
import csv
import sys
try:
    worklist = []
    with open('adult.csv','r') as fobj:
        #converting file object to csv object
        reader = csv.reader(fobj)
        #process
        for line in reader:
            workclass = line[1]
            if workclass not in worklist:
                worklist.append(workclass)
except Exception as err:  # default excepton # baseclass exception
    print(err)
    print(sys.exc_info())
else:
    # display output
    for work in worklist:
        print(work)
            