# -*- coding: utf-8 -*-
"""
write a program to display the files ONLY from the current directory 
"""




import os
try:
    files = os.listdir()
    for file in files:
        if os.path.isfile(file):
            print(file,"is a file")
except Exception as err:
    print(err)
