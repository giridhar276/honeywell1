'''
write a program to display the below IP addresses

c1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
'''



ip = '192.168.0.{}'
for val in range(1,11):
    print(ip.format(val))
    
    
ip = '192.168.0.'
for val in range(1,11):
    print(ip + str(val))
    
    
    
    