




import os

#os.mkdir("example")

try:
    for val in range(1,11):
        dirname = "dir" + str(val)
        if  os.path.isdir(dirname):
            os.rmdir(dirname)
            print(dirname,"deleted")
        else:
            print(dirname,"already exists")
except Exception as err:
    print(err)