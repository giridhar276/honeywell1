'''
write a program to display the below output

*
**
***
****
*****
******
*******
********
'''


for value in range(1,11):
    print('*' * value)