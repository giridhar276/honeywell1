
import sys
print(sys.modules.keys())


# empty file with today's timestamp
import time
filename = time.strftime('%d_%b_%Y.csv')
fobj = open(filename,'w')
fobj.close()