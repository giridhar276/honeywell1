# traditional way
# reading the file line by line
# fobj acts like cursor or pointer or handler
fobj = open('adult.csv','r')
for line in fobj:
    print(line.strip())
fobj.close()

# pythonic way
# context manager
# if any line starts with keyword with,we call it context manager
# Advantage : file gets closed automatically
with open('adult.csv','r') as fobj:
    for line in fobj:
        print(line.strip())
        print("----------")
    
# using csv library 
import csv   
with open('adult.csv','r') as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
        print("-----------")
        
    
    
    
    
    
    
    
    
# if the file is in the different path
#open(r'C:\Users\gsripath\Desktop\users\adult.csv','r') # raw string
#open('C:/Users/gsripath/Desktop/users/adult.csv','r'
with open('C:\\Users\\gsripath\\Desktop\\users\\adult.csv','r') as fobj:
    for line in fobj:
        print(line.strip())
            
# file write operation
with open('languages.txt','w') as fw:
    fw.write('python\n')
    fw.write('unix\n')

with open('numbers.txt','w') as fobj:
    for val in range(1,11):
        fobj.write(str(val) + "\n")
    
    
    
        
        
        



    
    
    
    


