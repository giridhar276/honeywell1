
'''
write a program to read adult.csv and display workclass and occupation colums only
'''
import sys
import csv   
try:
    with open('adult111.csv','r') as fobj:
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print("workclass :",line[1])
            print("occupation:",line[6])

except Exception as err:  # default excepton # baseclass exception
    print(err)
    print(sys.exc_info())