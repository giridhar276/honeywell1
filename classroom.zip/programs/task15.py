'''
write a program to display the below information

Total no. of males  : xxxx
Total no. of females: xx

'''

import csv
import sys
try:
    male = 0
    female = 0
    with open('adult.csv','r') as fobj:
        #converting file object to csv object
        reader = csv.reader(fobj)
        #process
        for line in reader:
            gender = line[9].strip()
            if gender == 'Male':
                male+=1
            elif gender == 'Female':
                female+=1
        
except Exception as err:  # default excepton # baseclass exception
    print(err)
    print(sys.exc_info())
else:
    print("Total male count  :", male)
    print("Total female count:", female)
            