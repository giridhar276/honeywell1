# simple if
a = 10
b = 2
if a > b:
    print("A is greater than B")
    print("inside if")
   
# if-else
name = 'python'
if name.isupper():
    print("string is upper")
else:
    print("string is lower")
    
# if-elif-elif-elif-else
lang = input("Enter any languages:")
if lang == 'python':
    print("its python")
elif lang == 'java':
    print("its java")
elif lang == "unix":
    print("its unix")
else:
    print("its some other language")