

'''
write a program to read filename as input from the keyboard and display the below output

example:

Enter any filename :  hello.txt

filename : hello
extension: txt

'''

filename = input("Enter any filename :")

output = filename.split(".")
print("Filename :",output[0])
print("Extension:",output[1])